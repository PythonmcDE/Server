package me.bluenitrox.school.mine.reward;

public enum Reward {

    REDSTONE,
    EMERALD,
    FLUGPULVER,
    REDSTONEBARREN;

}
