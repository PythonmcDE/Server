package me.bluenitrox.school.enchants;

public enum Enchant {

    SCHATZMEISTER,
    FLUCH,
    KOPFGELD,
    ASSASSINE,
    VAMPIR,
    KOBRA,
    ENERGIEENTZUG,
    ANTIVENOM,
    WILDEREI,
    JÄGER,
    ENTDECKER,

    TANK,
    HEILZAUBER,
    MAGIESCHILD,
    STACHELN,
    OBSIDIANSCHILD,
    EIS,
    Widerstand,
    Überladung,

    BLACKOUT,
    ZORN,
    LASER,
    DUPLIZIERUNG,
    ERFAHRUNG,
    AUSGRABUNG,

    GROßERFANG,
    FISCHERGLÜCK,
    GOLDHAKEN,

    ERHALT,
    RUNE;

}
