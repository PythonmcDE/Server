package me.bluenitrox.school.managers;

public class EnchantManager {

    /*
     *
     * Schwert
     * Enchantments
     *
     */

    public static final String schatzmeister = "§c§lSchatzmeister ";
    public static final String Fluch = "§c§lFluch ";
    public static final String Kopfgeld = "§c§lKopfgeld ";
    public static final String Assassine = "§c§lAssassine ";
    public static final String Vampir = "§c§lVampir ";
    public static final String Kobra = "§c§lKobra ";
    public static final String Energieentzug = "§c§lEnergieentzug ";
    public static final String AntiVenom = "§c§lAnti-Venom ";
    public static final String Wilderei = "§c§lWilderei ";
    public static final String Jäger = "§c§lJäger ";
    public static final String Entdecker = "§c§lEntdecker ";

    /*
     *
     * Rüstung
     * Enchantments
     *
     */

    public static final String Tank = "§a§lTank ";
    public static final String Heilzauber = "§a§lHeilzauber ";
    public static final String Magieschild = "§a§lMagieschild ";
    public static final String Stacheln = "§a§lStacheln ";
    public static final String ObsidianSchild = "§a§lObsidian-Schild ";
    public static final String Eis = "§a§lEis ";
    public static final String Widerstand = "§a§lWiderstand ";
    public static final String Überladung = "§a§lÜberladung ";

    /*
     *
     * Bogen
     * Enchantments
     *
     */

    public static final String Blackout = "§9§lBlackout ";
    public static final String Dynamite = "§9§lDynamite ";
    public static final String Tod = "§9§lTod ";
    public static final String Strahlen = "§9§lStrahlen ";
    public static final String Feuerwerk = "§9§lFeuerwerk ";
    public static final String Fesseln = "§9§lFesseln ";
    public static final String Elektrisiert = "§9§lElektrisiert ";

    /*
     *
     * Spitzhacken
     * Enchantments
     *
     */

    public static final String Rausch = "§6§lRausch ";
    public static final String Zorn = "§6§lZorn ";
    public static final String Laser = "§6§lLaser ";
    public static final String Duplizierung = "§6§lDuplizierung ";
    public static final String Erfahrung = "§6§lErfahrung ";
    public static final String Ausgrabung = "§6§lAusgrabung ";

    /*
     *
     * Angel
     * Enchantments
     *
     */

    public static final String Großerfang = "§6§lGroßer Fang ";
    public static final String Fischerglück = "§6§lFischerglück ";
    public static final String Goldhaken = "§6§lGoldhaken ";

    /*
     *
     * All
     * Enchantments
     *
     */

    public static final String Erhalt = "§f§lErhalt ";
    public static final String Rune = "§f§lRune ";

}
