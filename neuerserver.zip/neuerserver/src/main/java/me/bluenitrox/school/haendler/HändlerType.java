package me.bluenitrox.school.haendler;

public enum HändlerType {

    Förster,
    Magier,
    Techniker,
    Abenteurer,
    Koch,
    Bergmann,
    Bauarbeiter,
    Landwirt,
    Schmied,
    Gärtner,
    Künstlerin,
    TAXI;

}
