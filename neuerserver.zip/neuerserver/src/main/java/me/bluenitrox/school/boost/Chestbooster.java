package me.bluenitrox.school.boost;

public class Chestbooster extends Boost{

    public Chestbooster() {
        setName("§bChest-Booster");
        setLenth(25);
    }
}
