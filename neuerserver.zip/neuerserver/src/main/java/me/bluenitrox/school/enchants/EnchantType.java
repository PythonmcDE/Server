package me.bluenitrox.school.enchants;

public enum EnchantType {

    SWORD,
    BOW,
    PICKAXE,
    ARMOR;

}
