package me.bluenitrox.school.boost;

public interface BoosterEvent {

    void onStart();
    void onEnd();
}
