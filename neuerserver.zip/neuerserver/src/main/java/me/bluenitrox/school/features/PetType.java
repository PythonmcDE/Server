package me.bluenitrox.school.features;

public enum PetType {

    BENJAMIN,
    ANTON,
    FARID,
    HELGAR,
    PETER,
    MERLIN,
    EDDY;

}
